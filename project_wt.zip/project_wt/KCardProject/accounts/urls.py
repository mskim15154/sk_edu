from django.urls import path, re_path
from .views import register_view, login_view, dashboard_view, logout_view, home_view, verify_2fa, policy2_view

urlpatterns = [
    path('', home_view, name='home'),
    path('home/', home_view, name='home'),  
    path('register/', register_view, name='register'),
    path('policy2/', policy2_view, name='policy2'),
    re_path(r'^login/?$', login_view, name='login'),  # 슬래시 유무 허용
    path('dashboard/', dashboard_view, name='dashboard'),
    path('logout/', logout_view, name='logout'),
    path('verify_2fa/', verify_2fa, name='verify_2fa'),
]
