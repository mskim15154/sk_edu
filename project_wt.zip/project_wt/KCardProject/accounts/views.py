from django.contrib.auth import login, authenticate, logout
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm, LoginForm
from django.contrib.auth import get_user_model
import requests
import warnings

# SSL 경고 무시
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# 수탁사 API 엔드포인트 설정
TRUSTEE_API_BASE_URL = 'http://192.168.219.220:8001/api/'

# 수탁사에 사용자 등록 요청
def register_user_in_trustee(email, company_name):
    url = f'{TRUSTEE_API_BASE_URL}register_user/'
    data = {'email': email, 'company_name': company_name}
    try:
        response = requests.post(url, json=data, verify=False)
        if response.status_code == 201:
            return {'message': 'User registered successfully in trustee system.'}
        elif response.status_code == 200:
            return {'message': 'User already exists in trustee system.'}
        else:
            return {'error': 'Failed to register user in trustee system.'}
    except requests.exceptions.RequestException as e:
        return {'error': f'Connection error: {str(e)}'}

# 수탁사에 2차 인증 코드 전송 요청
def send_2fa_request(email):
    url = f'{TRUSTEE_API_BASE_URL}send_2fa_code/'
    data = {'email': email}
    print(f"Sending request to: {url} with data: {data}")  # 디버깅 출력 추가
    try:
        response = requests.post(url, json=data, verify=False)
        print(f"Response status: {response.status_code}, Response body: {response.text}")  # 응답 출력
        if response.status_code == 200 and response.headers.get('Content-Type') == 'application/json':
            return response.json()
        else:
            return {'error': 'Failed to request 2FA code. Server returned an error.'}
    except requests.exceptions.RequestException as e:
        return {'error': f'Connection error: {str(e)}'}

# 수탁사에 2차 인증 코드 검증 요청
def verify_2fa_request(email, code):
    url = f'{TRUSTEE_API_BASE_URL}verify_2fa_code/'
    data = {'email': email, 'code': code}
    try:
        response = requests.post(url, json=data, verify=False)
        if response.status_code == 200 and response.headers.get('Content-Type') == 'application/json':
            return response.json()
        else:
            return {'error': 'Failed to verify 2FA code. Server returned an error.'}
    except requests.exceptions.RequestException as e:
        return {'error': f'Connection error: {str(e)}'}

# 회원가입 뷰
def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()

            # 수탁사에 사용자 등록 요청
            company_name = "Your Company Name"  # 적절한 회사 이름으로 수정
            response = register_user_in_trustee(user.email, company_name)
            if 'error' in response:
                # 수탁사에 사용자 등록 실패 시 에러 메시지 출력
                return render(request, 'accounts/register.html', {'form': form, 'error': response['error']})
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form})

# 로그인 뷰 (2차 인증 요청 포함)
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                # 2차 인증을 위해 사용자 이메일을 임시 저장하고 수탁사에 인증 코드 요청
                request.session['temp_user_email'] = user.email
                response = send_2fa_request(user.email)
                if 'error' in response:
                    return render(request, 'accounts/login.html', {'form': form, 'error': response['error']})
                return redirect('verify_2fa')
            else:
                return render(request, 'accounts/login.html', {'form': form, 'error': '유효하지 않은 사용자입니다.'})
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})

# 2차 인증 확인 뷰
def verify_2fa(request):
    email = request.session.get('temp_user_email')
    if not email:
        return redirect('login')  # 세션이 만료된 경우 다시 로그인 페이지로 리디렉션

    if request.method == 'POST':
        code = request.POST.get('code')
        result = verify_2fa_request(email, code)
        if result.get('message') == '2차 인증이 완료되었습니다.':
            user = get_user_model().objects.get(email=email)
            login(request, user)
            del request.session['temp_user_email']
            return redirect('dashboard')
        else:
            error_message = result.get('error', '유효하지 않은 코드입니다.')
            return render(request, 'accounts/verify_2fa.html', {'error': error_message})
    return render(request, 'accounts/verify_2fa.html')

# 대시보드 뷰
@login_required
def dashboard_view(request):
    return render(request, 'accounts/dashboard.html', {'user': request.user})

# 로그아웃 뷰
def logout_view(request):
    logout(request)
    return redirect('home')  # 로그아웃 후 홈으로 리디렉트

# 홈 뷰
def home_view(request):
    context = {
        'user': request.user if request.user.is_authenticated else None,
        'is_logged_in': request.user.is_authenticated  # 로그인 여부 전달
    }
    return render(request, 'accounts/home.html', context)

# 개인정보 처리방침 뷰
def policy2_view(request):
    return render(request, 'accounts/policy2.html')
